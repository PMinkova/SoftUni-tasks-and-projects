﻿using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class RandomList : List<string>
    {
        private Random rnd;

        public string RemoveRandomElement()
        {
            int index = rnd.Next(0, this.Count);
            string element = this[index];
            return element;
            this.RemoveAt(index);
        }
    }
}

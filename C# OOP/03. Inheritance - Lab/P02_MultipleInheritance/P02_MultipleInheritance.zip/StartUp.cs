﻿using System;

namespace Farm
{
    public class StartUp
    {
        public static void Main()
        {
            Puppy puppy = new Puppy();
            puppy.Eat();
            puppy.Bark();
            puppy.Weep();
        }
    }
}

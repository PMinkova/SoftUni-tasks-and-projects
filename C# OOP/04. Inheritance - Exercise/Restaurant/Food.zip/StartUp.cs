﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        public static void Main()
        {
            var bev = new Beverage("Kola", 10, 100);
            Console.WriteLine(bev.Milliliters);
        }
    }
}
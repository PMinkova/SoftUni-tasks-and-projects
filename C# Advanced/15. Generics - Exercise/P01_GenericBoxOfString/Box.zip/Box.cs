﻿namespace P01_GenericBoxOfString
{
    public class Box<T>
    {
        private T value;

        public Box(T input)
        {
            this.value = input;
        }
        public override string ToString()
        {
            return $"System.String: {this.value}";
        }
    }
}
